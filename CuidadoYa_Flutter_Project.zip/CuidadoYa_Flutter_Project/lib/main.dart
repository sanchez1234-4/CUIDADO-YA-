
import 'package:flutter/material.dart';

void main() {
  runApp(CuidadoYaApp());
}

class CuidadoYaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CuidadoYa',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('CuidadoYa')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Bienvenido a CuidadoYa', style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: Text('Iniciar sesión'),
            ),
            ElevatedButton(
              onPressed: () {},
              child: Text('Registrarse'),
            ),
          ],
        ),
      ),
    );
  }
}
